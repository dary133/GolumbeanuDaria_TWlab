import { useState } from 'react'

const valoriInitiale = {
  oras: '',
  tara: '',
  zile: ''
}

function valideaza(valori) {
  const erori = {}

  if (valori.oras.trim().length < 2) {
    erori.oras = 'Orașul are cel puțin două caractere.'
  }

  if (valori.tara.trim() === '') {
    erori.tara = 'Țara este obligatorie.'
  }

  const numarZile = Number(valori.zile)

  if (
    valori.zile === '' ||
    !Number.isInteger(numarZile) ||
    numarZile < 1 ||
    numarZile > 30
  ) {
    erori.zile = 'Numărul de zile este între 1 și 30.'
  }

  return erori
}

export default function FormularDestinatie({ onAdd, seTrimite }) {
  const [valori, setValori] = useState(valoriInitiale)
  const [erori, setErori] = useState({})

  function handleChange(event) {
    const { name, value } = event.target

    setValori((curent) => ({
      ...curent,
      [name]: value
    }))
  }

  async function handleSubmit(event) {
    event.preventDefault()

    const eroriGasite = valideaza(valori)
    setErori(eroriGasite)

    if (Object.keys(eroriGasite).length > 0) {
      return
    }

    const salvat = await onAdd({
      oras: valori.oras.trim(),
      tara: valori.tara.trim(),
      zile: Number(valori.zile),
      vizitat: false
    })

    if (salvat) {
      setValori(valoriInitiale)
      setErori({})
    }
  }

  return (
    <form className="formular" onSubmit={handleSubmit} noValidate>

      <div className="camp">
        <input
          name="oras"
          placeholder="Oraș"
          value={valori.oras}
          onChange={handleChange}
          className={erori.oras ? 'invalid' : ''}
        />

        {erori.oras && (
          <p className="eroare-camp">{erori.oras}</p>
        )}
      </div>

      <div className="camp">
        <input
          name="tara"
          placeholder="Țară"
          value={valori.tara}
          onChange={handleChange}
          className={erori.tara ? 'invalid' : ''}
        />

        {erori.tara && (
          <p className="eroare-camp">{erori.tara}</p>
        )}
      </div>

      <div className="camp">
        <input
          type="number"
          name="zile"
          placeholder="Zile"
          value={valori.zile}
          onChange={handleChange}
          className={erori.zile ? 'invalid' : ''}
        />

        {erori.zile && (
          <p className="eroare-camp">{erori.zile}</p>
        )}
      </div>

      <button type="submit" disabled={seTrimite}>
        {seTrimite ? 'Se trimite...' : 'Adaugă'}
      </button>

    </form>
  )
}