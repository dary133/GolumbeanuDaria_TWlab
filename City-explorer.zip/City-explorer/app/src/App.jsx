import { useEffect, useState } from 'react'
import PanouStatistici from './components/PanouStatistici.jsx'
import {
  getDestinatii,
  postDestinatie,
  patchVizitat
} from './api/destinatii.js'

import {
  getNevizitate,
  totalZile
} from './utils/destinatii.js'

import ListaDestinatii from './components/ListaDestinatii.jsx'
import FormularDestinatie from './components/FormularDestinatie.jsx'
import Rezumat from './components/Rezumat.jsx'
import Cautare from './components/Cautare.jsx'

import './App.css'

export default function App() {

  const [destinatii, setDestinatii] = useState([])
  const [incarcare, setIncarcare] = useState(true)
  const [eroare, setEroare] = useState(null)

  const [seTrimite, setSeTrimite] = useState(false)
  const [eroareActiune, setEroareActiune] = useState(null)
  const [cautare, setCautare] = useState('')

  useEffect(() => {
    let activ = true

    async function incarca() {
      try {
        const date = await getDestinatii()

        if (activ) {
          setDestinatii(date)
        }

      } catch (error) {
        if (activ) {
          setEroare(error.message)
        }

      } finally {
        if (activ) {
          setIncarcare(false)
        }
      }
    }

    incarca()

    return () => {
      activ = false
    }

  }, [])

  async function handleToggle(id) {
    const destinatie = destinatii.find((d) => d.id === id)

    if (!destinatie) {
      return
    }

    setEroareActiune(null)

    try {
      const salvata = await patchVizitat(
        id,
        !destinatie.vizitat
      )

      setDestinatii((curent) =>
        curent.map((d) =>
          d.id === id ? salvata : d
        )
      )

    } catch (error) {
      setEroareActiune(error.message)
    }
  }

  async function handleAdd(destinatie) {
    setSeTrimite(true)
    setEroareActiune(null)

    try {
      const salvata = await postDestinatie(destinatie)

      setDestinatii((curent) => [
        ...curent,
        salvata
      ])

      return true

    } catch (error) {
      setEroareActiune(error.message)
      return false

    } finally {
      setSeTrimite(false)
    }
  }

  const text = cautare.trim().toLowerCase()

  const afisate = destinatii.filter(
    (d) =>
      d.oras.toLowerCase().includes(text) ||
      d.tara.toLowerCase().includes(text)
  )

  const nevizitate = getNevizitate(destinatii)

  return (
    <main>

      <h1>City Explorer</h1>
      <PanouStatistici />
      {incarcare ? (

        <p className="stare">
          Se încarcă destinațiile...
        </p>

      ) : eroare ? (

        <p className="stare eroare">
          Eroare: {eroare}
        </p>

      ) : (

        <>
          <Rezumat
            total={destinatii.length}
            nevizitate={nevizitate.length}
            zile={totalZile(nevizitate)}
          />

          <FormularDestinatie
            onAdd={handleAdd}
            seTrimite={seTrimite}
          />

          {eroareActiune && (
            <p className="stare eroare">
              {eroareActiune}
            </p>
          )}

          <Cautare
            valoare={cautare}
            onChange={setCautare}
          />

          {destinatii.length === 0 ? (

            <p className="gol">
              Nu există destinații. Adaugă una folosind formularul.
            </p>

          ) : afisate.length === 0 ? (

            <p className="gol">
              Niciun rezultat pentru «{cautare.trim()}».
            </p>

          ) : (

            <ListaDestinatii
              destinatii={afisate}
              onToggle={handleToggle}
            />

          )}
        </>

      )}

    </main>
  )
}